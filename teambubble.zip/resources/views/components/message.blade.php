<div class="message-box">
<img src="{{asset('images/uploads/default.svg')}}" alt="avatar">
    <div class="message-content">
        <div class="message-header">
            <div class="name">Lars</div>
        </div>
        <p class="message-line">
            Hey!!!
        </p>
        <p class="message-line time">
            Dec, 12
        </p>
    </div>
</div>
