<div class="form-group">
    <label for="{{$label}}">{{$labelname}}</label>
    <input type="{{$type}}" class="form-control" name="{{$label}}" id="{{$label}}" placeholder="{{$placeholder}}">
</div>