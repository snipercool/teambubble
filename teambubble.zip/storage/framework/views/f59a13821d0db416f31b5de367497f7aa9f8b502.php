<div class="form-group">
    <label for="<?php echo e($label); ?>"><?php echo e($labelname); ?></label>
    <input type="<?php echo e($type); ?>" class="form-control" name="<?php echo e($label); ?>" id="<?php echo e($label); ?>" placeholder="<?php echo e($placeholder); ?>">
</div><?php /**PATH C:\Users\Gebruiker\Desktop\2020-2021\eindwerk\teambubble\resources\views/components/input.blade.php ENDPATH**/ ?>