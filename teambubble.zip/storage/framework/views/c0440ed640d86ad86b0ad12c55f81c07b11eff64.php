<div class="message-box">
<img src="<?php echo e(asset('images/uploads/default.svg')); ?>" alt="avatar">
    <div class="message-content">
        <div class="message-header">
            <div class="name">Lars</div>
        </div>
        <p class="message-line">
            Hey!!!
        </p>
        <p class="message-line time">
            Dec, 12
        </p>
    </div>
</div>
<?php /**PATH C:\Users\Gebruiker\Desktop\2020-2021\eindwerk\teambubble\resources\views/components/message.blade.php ENDPATH**/ ?>