<?php if(session('<?php echo e($sessionMessage); ?>')): ?>
    <div class="alert <?php echo e($alert-type); ?>">
        <div onclick="this.parentElement.style.display = 'none';" class="alert-closebtn">X</div>
        <?php echo e($message); ?>

    </div>
<?php endif; ?>

<!-- <?php if(session('mailSuccess')): ?>
    <div class="alert alert-success">
        <div onclick="this.parentElement.style.display = 'none';" class="alert-closebtn">X</div>
        <?php echo e(__('app.mailSuccess')); ?>

    </div>
<?php endif; ?>

<?php if(session('updateSuccess')): ?>
    <div class="alert alert-success">
        <div onclick="this.parentElement.style.display = 'none';" class="alert-closebtn">X</div>
        <?php echo e(__('app.updateSuccess')); ?>

    </div>
<?php endif; ?>

<?php if(session('DeleteSuccess')): ?>
    <div class="alert alert-success">
        <div onclick="this.parentElement.style.display = 'none';" class="alert-closebtn">X</div>
        <?php echo e(__('app.DeleteSuccess')); ?>

    </div>
<?php endif; ?>

<?php if(session('Error')): ?>
    <div class="alert alert-danger">
        <div onclick="this.parentElement.style.display = 'none';" class="alert-closebtn">X</div>
        <?php echo e(__('app.error')); ?>

    </div>
<?php endif; ?> --><?php /**PATH C:\Users\Gebruiker\Desktop\2020-2021\eindwerk\teambubble\resources\views/components/alerts.blade.php ENDPATH**/ ?>