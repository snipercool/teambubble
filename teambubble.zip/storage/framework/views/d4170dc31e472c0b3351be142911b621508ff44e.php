<div class="project-box-wrapper" style="<?php if($event->done == 1): ?>opacity:0.5;<?php endif; ?>">
    <div class="project-box" style="background-color: #AED6F1;">
        <div class="project-box-header">
            <span>Start: <?php echo e($event->start); ?></span>
        </div>
        <div class="project-box-content-header event-header">
            <span>End: <?php echo e($event->end); ?></span>
        </div>
        <div class="box-progress-wrapper">
            <p class="box-content-header event-title"><?php echo e($event->title); ?></p>
        </div>
        <div class="project-box-footer">
            <div class="days-left" style="color: #007adf;">
            <?php
                    $d1 = strtotime($event->end);
                    $d2=ceil(($d1-time())/60/60/24);
                ?>
                <?php if($d2 <= 0): ?>
                    <?php echo e(__('app.overdate')); ?>

                <?php else: ?>
                    <?php echo e($d2); ?> <?php echo e(__('app.daysleft')); ?>

                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Gebruiker\Desktop\2020-2021\eindwerk\teambubble\resources\views/components/event.blade.php ENDPATH**/ ?>