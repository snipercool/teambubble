

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('components.headerapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="app-content">
    <div class="user-section">
        <div class="user-section-header">
            <p>Account</p>
        </div>
        <div class="user-section-line">
            <span class="status-number"><img src="<?php echo e($user->avatar); ?>" alt="avatar"></span>
            <span class="status-type"><?php echo e($user->name); ?></span>
        </div>
        <form class="user-form" action="/update" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo $__env->make('components.input',[
            'label' => 'name',
            'type' => 'text',
            'labelname' => __('auth.name'),
            'placeholder' => $user->name,
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('components.input',[
            'label' => 'email',
            'type' => 'email',
            'labelname' => __('auth.email'),
            'placeholder' => $user->email,
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('components.input',[
            'label' => 'avatar',
            'type' => 'file',
            'labelname' => 'avatar',
            'placeholder' => '',
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('components.input',[
            'label' => 'password',
            'type' => 'password',
            'labelname' => __('auth.password'),
            'placeholder' => '*******',
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('components.input',[
            'label' => 'password-confirm',
            'type' => 'password',
            'labelname' => __('auth.password-confirm'),
            'placeholder' => '*******',
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <button type="submit"><?php echo e(__('auth.submit')); ?></button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Gebruiker\Desktop\2020-2021\eindwerk\teambubble\resources\views/user.blade.php ENDPATH**/ ?>