<div class="project-box-wrapper" style="<?php if($project->done == 1): ?>opacity:0.5;<?php endif; ?>">
    <div class="project-box" style="background-color: #AED6F1;">
        <div class="project-box-header">
            <span><?php echo e($project->endday); ?></span>
            <div class="more-wrapper">
                <button class="project-btn-more">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"
                        stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                        class="feather feather-more-vertical">
                        <circle cx="12" cy="12" r="1" />
                        <circle cx="12" cy="5" r="1" />
                        <circle cx="12" cy="19" r="1" /></svg>
                </button>
                <div class="more-wrapper-content">
                    <button><a href="/project/<?php echo e($project->id); ?>"><?php echo e(__('app.goproject')); ?></a></button>
                    <?php if($project->done == 0): ?>
                    <button><a href="/project/markdone/<?php echo e($project->id); ?>"><?php echo e(__('app.markdone')); ?></a></button>
                    <?php else: ?>
                    <button><a href="/project/marknotdone/<?php echo e($project->id); ?>"><?php echo e(__('app.marknotdone')); ?></a></button>
                    <?php endif; ?>
                    <?php if(Auth::user()->id == $project->createdby): ?>
                    <button><a href="/project/delete/<?php echo e($project->id); ?>"><?php echo e(__('app.deleteproject')); ?></a></button>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="project-box-content-header">
            <a href="/project/<?php echo e($project->id); ?>">
                <p class="box-content-header"><?php echo e($project->name); ?></p>
            </a>
        </div>
        <?php
        $percent = 0
        ?>
        <?php if(count($progress) != 0): ?>
        <?php
        $percent = count($progress) / count($events) * 100;
        ?>
        <?php endif; ?>
        <div class="box-progress-wrapper">
            <p class="box-progress-header">Progress</p>
            <div class="box-progress-bar">
                <span class="box-progress" style="width: <?php echo e($percent); ?>%; background-color: #007adf"></span>
            </div>
            <p class="box-progress-percentage"><?php echo e($percent); ?>%</p>
        </div>
        <div class="project-box-footer">
            <div class="participants">
                <img src="<?php echo e($createduser[0]->avatar); ?>"
                    alt="participant">
                <?php $__currentLoopData = $team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <img src="<?php echo e($person->avatar); ?>"
                    alt="participant">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e($project->id); ?>/invitation" class="add-participant" style="color: #007adf;">
                    <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none"
                        stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"
                        class="feather feather-plus">
                        <path d="M12 5v14M5 12h14" />
                    </svg>
                </a>
            </div>
            <div class="days-left" style="color: #007adf;">
                <?php
                    $d1 = strtotime($project->endday);
                    $d2=ceil(($d1-time())/60/60/24);
                ?>
                <?php if($d2 <= 0): ?>
                    <?php echo e(__('app.overdate')); ?>

                <?php else: ?>
                    <?php echo e($d2); ?> <?php echo e(__('app.daysleft')); ?>

                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Gebruiker\Desktop\2020-2021\eindwerk\teambubble\resources\views/components/project.blade.php ENDPATH**/ ?>