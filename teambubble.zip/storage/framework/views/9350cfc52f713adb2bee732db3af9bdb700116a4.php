<body style="margin: 0; padding:0; font-family: sans-serif;">
<div style="width: 100%; height:100%; padding:31px; margin:0; background-color:#007adf; color: white;">
    <img src="<?php echo e(asset('images/logo.svg')); ?>" alt="Teambubble" height="75px">
    <h1>You have received an invitation from <?php echo e($name); ?>.</h1>

    <p>Follow this link to access the project:</p>
    <a style="font-weight: bold; color:white; text-decoration:none;" href="<?php echo e($body); ?>" target="_blank" rel="noopener noreferrer"><?php echo e($body); ?></a>
</div>

</body>
<?php /**PATH C:\Users\Gebruiker\Desktop\2020-2021\eindwerk\teambubble\resources\views/mail.blade.php ENDPATH**/ ?>