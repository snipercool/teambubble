<div class="project-box-wrapper">
    <div class="project-box" style="background-color: #AED6F1;">
        <div class="project-box-content-header">
                <p class="box-content-header"><?php echo e($file->name); ?></p>
        </div>
        <div class="project-box-footer">
           <a href="<?php echo e(asset($file->path)); ?>" download="<?php echo e($file->name); ?>">Download</a>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Gebruiker\Desktop\2020-2021\eindwerk\teambubble\resources\views/components/file.blade.php ENDPATH**/ ?>