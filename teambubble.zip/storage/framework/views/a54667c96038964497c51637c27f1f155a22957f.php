<?php if(session('projectSuccess')): ?>
    <div class="alert alert-success">
        <div onclick="this.parentElement.style.display = 'none';" class="alert-closebtn">X</div>
        <?php echo e(__('app.projectcreated')); ?>

    </div>
<?php endif; ?>

<?php if(session('DeleteSuccess')): ?>
    <div class="alert alert-success">
        <div onclick="this.parentElement.style.display = 'none';" class="alert-closebtn">X</div>
        <?php echo e(__('app.projectdeleted')); ?>

    </div>
<?php endif; ?><?php /**PATH C:\Users\Gebruiker\Desktop\2020-2021\eindwerk\teambubble\resources\views/components/messages.blade.php ENDPATH**/ ?>