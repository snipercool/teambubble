

<?php $__env->startSection('content'); ?>
<script src='http://fullcalendar.io/js/fullcalendar-2.1.1/lib/jquery.min.js'></script>
<script src="http://fullcalendar.io/js/fullcalendar-2.1.1/lib/jquery-ui.custom.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/fullcalendar@5.6.0/locales-all.js"></script>
<script src="https://cdn.jsdelivr.net/npm/fullcalendar@5.6.0/main.min.js"></script>
<link href='https://cdn.jsdelivr.net/npm/bootstrap@4.5.0/dist/css/bootstrap.css' rel='stylesheet' />
<link href='https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.13.1/css/all.css' rel='stylesheet'>
<?php echo $__env->make('components.headerapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="app-content">
    <?php echo $__env->make('components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
        document.querySelector('#cal').classList.add('active');
    </script>
    <div class="projects-section">
        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div id="<?php echo e($event->id); ?>" class="model">
            <div class="model__content">
                <div class="close_btn" onclick="$('#<?php echo e($event->id); ?>').toggleClass('model--show')">X</div>
                <h3 class="model__title"><?php echo e($event->title); ?></h3>
                <form action="<?php echo e(Request::url()); ?>/updateevent" method="post">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" value="<?php echo e($event->id); ?>">
                    <div class="form-group form-name">
                    <label for="name"><?php echo e(__('auth.name')); ?></label>
                    <input id="name" type="text" class="<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name"
                        value="<?php echo e(old('name')); ?>" autocomplete="name" autofocus
                        placeholder="<?php echo e(__('auth.name')); ?>">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                    <div class="form-group form-startdate">
                    <label for="startdate"><?php echo e(__('auth.startdate')); ?></label>
                    <input id="startdate" type="datetime-local" class="<?php $__errorArgs = ['startdate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="startdate"
                        value="<?php echo e(old('startdate')); ?>" autocomplete="startdate" autofocus
                        placeholder="<?php echo e(__('auth.startdate')); ?>">
                    <?php $__errorArgs = ['startdate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group form-enddate">
                    <label for="enddate"><?php echo e(__('auth.enddate')); ?></label>
                    <input id="enddate" type="datetime-local" class="<?php $__errorArgs = ['enddate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="enddate"
                        value="<?php echo e(old('enddate')); ?>" autocomplete="enddate" autofocus
                        placeholder="<?php echo e(__('auth.enddate')); ?>">
                    <?php $__errorArgs = ['enddate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group form-assignees">
                    <label for="assignees"><?php echo e(__('auth.assignees')); ?></label>
                    <select name="assignees" id="assignees"  multiple>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($usr->id); ?>" style="background-image:'<?php echo e($usr->avatar); ?>'; background-size: 'contain';"><?php echo e($usr->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group form-enddate">
                    <label for="done"><?php echo e(__('auth.done')); ?></label>
                    <input type="checkbox" name="done" id="done">
                </div>

                <div class="form-group form-submit">
                <button type="submit" class="btn btn-primary">
                    <?php echo e(__('auth.submit')); ?>

                </button>
                </div>
                </form>
                <button onclick="deleteevent(<?php echo e($event->id); ?>)" class="btn btn--close">Delete event</button>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       
        <div id="calendar"></div>
        <script>
            document.addEventListener('DOMContentLoaded', function () {
                var calendarEl = document.getElementById('calendar');
                var SITEURL = "<?php echo e(Request::url()); ?>";
                var eventsarray = <?php echo $events; ?>;

                var calendar = new FullCalendar.Calendar(calendarEl, {
                    locale: 'en',
                    themeSystem: 'bootstrap',
                    initialView: 'dayGridMonth',
                    headerToolbar: {
                        start: 'prev,next today',
                        center: 'title',
                        end: 'dayGridMonth,timeGridSevenDay,listWeek'
                    },
                    height: 800,
                    events: eventsarray,
                    editable: true,
                    eventRender: function (event, element, view) {
                    if (event.allDay === 'true') {
                    event.allDay = true;
                    } else {
                    event.allDay = false;
                    }
                    },
                    views: {
                        timeGridSevenDay: {
                            type: 'timeGrid',
                            duration: {
                                days: 7
                            },
                            buttonText: 'week'
                        }
                    },
                    eventClick: async function(event) {
                        event.jsEvent.preventDefault(); // don't let the browser navigate
                        console.log(event.event.id);
                        $('#'+event.event.id).toggleClass('model--show');
                    }
                });
                calendar.setOption('locale', 'nl');
                calendar.render();
                
            });

            function deleteevent($id){
                let _token   = $('meta[name="csrf-token"]').attr('content');
                var SITEURL = "<?php echo e(Request::url()); ?>";
                $.ajax({
                    url: SITEURL+"/deleteevent",
                    type:"POST",
                    data:{
                    id:$id,
                    _token: _token
                    },
                    success:function(response){
                        location.reload();
                    },
                });
            }

        </script>

    </div>
    <div class="messages-section">
        <div class="projects-section-header">
            <p><?php echo e(__('app.tasks')); ?></p>
        </div>
        <div class="messages">
            <form action="<?php echo e(Request::url()); ?>/addevent" method="post">
                <?php echo csrf_field(); ?>
                <div class="form-group form-name">
                    <label for="name"><?php echo e(__('auth.name')); ?></label>
                    <input id="name" type="text" class="<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name"
                        value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus
                        placeholder="<?php echo e(__('auth.name')); ?>">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group form-startdate">
                    <label for="startdate"><?php echo e(__('auth.startdate')); ?></label>
                    <input id="startdate" type="datetime-local" class="<?php $__errorArgs = ['startdate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="startdate"
                        value="<?php echo e(old('startdate')); ?>" required autocomplete="startdate" autofocus
                        placeholder="<?php echo e(__('auth.startdate')); ?>">
                    <?php $__errorArgs = ['startdate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <input type="hidden" name="type" id="type" value="add">
                </div>
                <div class="form-group form-enddate">
                    <label for="enddate"><?php echo e(__('auth.enddate')); ?></label>
                    <input id="enddate" type="datetime-local" class="<?php $__errorArgs = ['enddate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="enddate"
                        value="<?php echo e(old('enddate')); ?>" required autocomplete="enddate" autofocus
                        placeholder="<?php echo e(__('auth.enddate')); ?>">
                    <?php $__errorArgs = ['enddate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group form-assignees">
                    <label for="assignees"><?php echo e(__('auth.assignees')); ?></label>
                    <select name="assignees" id="assignees"  multiple>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($usr->id); ?>" style="background-image:'<?php echo e($usr->avatar); ?>'; background-size: 'contain';"><?php echo e($usr->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group form-submit">
                <button type="submit" class="btn btn-primary">
                    <?php echo e(__('auth.submit')); ?>

                </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Gebruiker\Desktop\2020-2021\eindwerk\teambubble\resources\views/calendar.blade.php ENDPATH**/ ?>