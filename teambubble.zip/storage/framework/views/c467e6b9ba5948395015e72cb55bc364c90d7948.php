<?php $__env->startSection('content'); ?>
<div class="app-content bg-blue-gradient">
<div class="app-content-leftauth">
    <img src="<?php echo e(asset('images/logo.svg')); ?>" alt="Teambubble Logo">
</div>
<div class="app-content-rightauth">
    <img src="<?php echo e(asset('images/logo.svg')); ?>" alt="Teambubble Logo" class="logo-mobile">
    <h1 class="form-title"><?php echo e(__('auth.welcomeback')); ?></h1>
    <a href="<?php echo e(route('login.google')); ?>" class="btn btn-google">
        <img class="icon" src="https://s2.svgbox.net/social.svg?color=white&ic=google" alt="Google"> Login with Google</a>
    <hr class="form-or">

    <form method="POST" action="<?php echo e(route('login')); ?>">
        <?php echo csrf_field(); ?>
        <div class="form-group form-email">
            <label for="email"><?php echo e(__('auth.email')); ?></label>
            <input id="email" type="email" class="<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email"
                value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus placeholder="<?php echo e(__('auth.email')); ?>">
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group form-password">
            <label for="password"><?php echo e(__('auth.password')); ?></label>
            <input id="password" type="password" class="<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                name="password" required autocomplete="current-password" placeholder="<?php echo e(__('auth.password')); ?>">
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group form-remember">
            <div class="form-check">
                <input class="form-check-input" type="checkbox" name="remember" id="remember"
                    <?php echo e(old('remember') ? 'checked' : ''); ?>>

                <label class="form-check-label" for="remember">
                    <?php echo e(__('auth.rememberme')); ?>

                </label>
            </div>
        </div>
        <div class="form-group form-submit">
            <button type="submit" class="btn btn-primary">
                <?php echo e(__('auth.Login')); ?>

            </button>

            <?php if(Route::has('password.request')): ?>
            <a class="btn-link" href="<?php echo e(route('password.request')); ?>">
                <?php echo e(__('auth.forgotpassword')); ?>

            </a>
            <?php endif; ?>

            <?php if(Route::has('register')): ?>
            <a class="btn-link" href="<?php echo e(route('register')); ?>">
                <?php echo e(__('auth.noaccount')); ?>

            </a>
            <?php endif; ?>
        </div>
    </form>
    <div class="localization-buttons">
        <a href="<?php echo e(url('/locale/nl')); ?>">NL</a> |
        <a href="<?php echo e(url('/locale/en')); ?>">EN</a>
    </div>
</div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Gebruiker\Desktop\2020-2021\eindwerk\teambubble\resources\views/auth/login.blade.php ENDPATH**/ ?>