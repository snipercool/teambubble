

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('components.headerapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="app-content">
    <div class="projects-section">
        <div class="projects-section-header">
            <p><?php echo e(__('app.invitation')); ?></p>
        </div>
        <form class="user-form" action="" method="post">
            <?php echo csrf_field(); ?>
            <?php echo $__env->make('components.input',[
            'label' => 'email',
            'type' => 'email',
            'labelname' => __('app.sendinvite'),
            'placeholder' => 'John.Doe@gmail.com',
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <button type="submit"><?php echo e(__('auth.submit')); ?></button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Gebruiker\Desktop\2020-2021\eindwerk\teambubble\resources\views/invitation.blade.php ENDPATH**/ ?>